# Guide très simple — mettre Best Poulet en ligne gratuitement avec GitHub + Netlify

Ce guide est destiné à une personne qui n'a jamais créé de site. Tu n'as pas besoin d'écrire de code ni d'utiliser le terminal.

**Avant de communiquer le site aux clients :** le pied de page contient encore un rappel pour compléter les mentions légales exactes de la société. Ces informations ne peuvent pas être devinées. Le numéro de téléphone actuellement intégré est le **01 78 71 28 37** ; confirme-le avant publication.

## Avant de commencer

Télécharge `Best_Poulet_Site_GitHub_Logo_Visuels.zip` et décompresse-le : clic droit sur le ZIP → **Extraire tout…** → **Extraire**.
Tu dois voir les fichiers `index.html`, `README.md`, `robots.txt`, `netlify.toml` et le dossier `assets` contenant le logo et tous les visuels des produits.

**Ne téléverse pas le ZIP lui-même.** Tu dois téléverser les fichiers extraits, en gardant `index.html` à la racine du dépôt.

## Pourquoi GitHub + Netlify plutôt que GitHub Pages ?

- **GitHub** garde les fichiers du site et l'historique des modifications.
- **Netlify** publie le site sur Internet et peut le republier automatiquement lorsque tu modifies les fichiers dans GitHub.
- GitHub Pages n'est pas destiné à héberger gratuitement un site d'entreprise principalement orienté vers les transactions commerciales. Comme Best Poulet veut recevoir des commandes par téléphone, la configuration conseillée est GitHub pour les fichiers et Netlify pour la publication.
- Le forfait Netlify Free est affiché à **0 $/mois**, avec une limite de 300 crédits par mois. Si la limite est atteinte, le site peut être mis en pause jusqu'au prochain cycle. Le forfait gratuit a un plafond ferme et ne peut pas être facturé au-delà de ce plafond ; n'active pas d'offre payante si tu veux rester à 0 €.

Liens officiels :
- GitHub : https://github.com/
- Créer un dépôt GitHub : https://github.com/new
- Aide GitHub — créer un dépôt : https://docs.github.com/en/repositories/creating-and-managing-repositories/creating-a-new-repository
- Netlify : https://www.netlify.com/
- Netlify — connecter un dépôt Git : https://docs.netlify.com/start/quickstarts/deploy-from-repository/
- Tarifs Netlify : https://www.netlify.com/pricing/
- Limites de GitHub Pages : https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits

---

## Étape 1 — créer le dépôt GitHub

1. Ouvre https://github.com/new et connecte-toi.
2. Dans **Repository name**, écris `best-poulet-meaux-site`.
3. Dans la description, écris par exemple `Site vitrine de Best Poulet — rôtisserie à Meaux`.
4. Choisis **Public**. C'est normal pour un site vitrine : le HTML et les images doivent être publics. Ne mets jamais de mot de passe, de coordonnées bancaires ni d'informations privées dans le dépôt.
5. Si une option **Add a README file** apparaît, tu peux la laisser décochée pour éviter un conflit lors du premier envoi.
6. Clique sur **Create repository**.

Le dépôt est le dossier en ligne de ton site. Laisse la page ouverte.

## Étape 2 — envoyer les fichiers du site dans GitHub

1. Ouvre le dossier où tu as extrait le ZIP.
2. Dans GitHub, sur la page du dépôt, choisis **Add file** → **Upload files**.
3. Depuis l'Explorateur de fichiers Windows, sélectionne les éléments à l'intérieur du dossier extrait : `index.html`, `README.md`, `robots.txt`, `netlify.toml` et le dossier `assets`.
4. Glisse ces éléments dans la page GitHub. Vérifie que `index.html` est au premier niveau du dépôt et que le dossier `assets` contient le logo et les visuels produits.
5. En bas de page, dans **Commit changes**, écris `Ajout du site Best Poulet`.
6. Clique sur **Commit changes**.
7. Vérifie ensuite que tu vois `index.html` au même niveau que `assets` dans le dépôt. Si tu vois seulement un dossier `site` ou un autre dossier contenant `index.html`, tu as envoyé un niveau de dossier en trop : recommence en envoyant le contenu du dossier, pas son dossier parent.

Documentation officielle pour l'envoi de fichiers : https://docs.github.com/en/repositories/working-with-files/managing-files/adding-a-file-to-a-repository

## Étape 3 — créer le compte Netlify gratuit

1. Ouvre https://app.netlify.com/signup (ou https://app.netlify.com/ si tu as déjà un compte).
2. Choisis **Sign up with GitHub** si cette option apparaît. C'est le plus simple : GitHub et Netlify pourront communiquer.
3. Si Netlify demande une autorisation d'accès à GitHub, autorise l'accès au dépôt `best-poulet-meaux-site` seulement si ce choix est proposé.

## Étape 4 — publier le site depuis le dépôt GitHub

1. Dans Netlify, ouvre le tableau de bord des projets et clique **Add new project** → **Import an existing project**.
2. Choisis **GitHub** comme fournisseur.
3. Si une autorisation est demandée, confirme-la, puis sélectionne le dépôt `best-poulet-meaux-site`.
4. Dans les paramètres de publication, utilise ces valeurs si les champs sont demandés :
   - **Branch** : `main` (ou la branche principale affichée par GitHub).
   - **Base directory** : laisser vide.
   - **Build command** : laisser vide — ce site HTML est déjà prêt.
   - **Publish directory** : `.` (la racine du dépôt).
5. Clique sur **Deploy** / **Publish**.
6. Attends que Netlify affiche le succès du déploiement. L'adresse publique se terminera par `.netlify.app`.

Si Netlify ne détecte pas le dépôt, vérifie dans les autorisations de Netlify/GitHub que le dépôt `best-poulet-meaux-site` est bien autorisé.

## Étape 5 — choisir une adresse facile à retenir

1. Dans les réglages du site Netlify, cherche **Site name** ou **Change site name**.
2. Essaie `best-poulet-meaux`.
3. Si ce nom est disponible, l'adresse ressemblera à `https://best-poulet-meaux.netlify.app`. Sinon, essaie une variante comme `best-poulet-meaux-77`.

L'adresse exacte est connue uniquement après la création et la vérification de disponibilité. C'est un sous-domaine gratuit de Netlify, pas un nom de domaine personnalisé en `.fr`.

## Étape 6 — vérifier le bouton d'appel avant de partager le site

Ouvre le site publié sur un ordinateur puis sur un téléphone et vérifie :

- le bouton **Appeler pour passer commande** apparaît dans le menu, dans la section d'accueil et en bas de l'écran sur mobile ;
- sur un smartphone, un appui sur le bouton ouvre l'application Téléphone avec le numéro du restaurant ;
- le numéro affiché est bien **01 78 71 28 37** ;
- les prix du site correspondent toujours au flyer et au menu en restaurant ;
- l'adresse, l'itinéraire Google Maps et les horaires (11 h–23 h) sont corrects ;
- les photos et le logo s'affichent.

Sur un ordinateur, un lien `tel:` peut ouvrir une application de téléphonie configurée ou ne rien faire : ce n'est pas un bug du site. Le comportement à tester en priorité est celui du smartphone.

## Étape 7 — compléter les mentions légales

Le bas du site contient un rappel **« À compléter avant publication »**. Il ne faut pas le laisser tel quel sur la version publique. Remplace-le par les mentions légales exactes de la société : dénomination, forme juridique, siège, immatriculation, responsable de publication et informations d'hébergement applicables.

Pour faire une correction directement dans GitHub sans logiciel :
1. Ouvre `index.html` dans le dépôt GitHub.
2. Clique sur le crayon (**Edit this file**).
3. Utilise `Ctrl + F` pour trouver `À compléter avant publication`.
4. Modifie uniquement le bloc concerné en utilisant les informations légales exactes de la société. Ne les invente pas.
5. Clique sur **Commit changes**.
6. Netlify republiera automatiquement le site après la modification du dépôt.

## Étape 8 — ajouter le site à Google gratuitement

1. Une fois que Netlify a donné une adresse publique, copie cette adresse.
2. Ouvre https://search.google.com/search-console/.
3. Ajoute une propriété de type **Préfixe de l'URL** et colle l'adresse complète commençant par `https://`.
4. Suis une méthode de validation proposée par Google.
5. Utilise **Inspection de l'URL**, puis demande l'indexation de la page d'accueil.

L'indexation peut prendre du temps et ne garantit pas le classement numéro 1. Search Console t'aidera à suivre les impressions, les clics et les requêtes utilisées par les internautes.

## Étape 9 — modifier un prix ou une photo plus tard

Pour le prix ou les textes : ouvre `index.html` dans GitHub, clique sur le crayon, utilise `Ctrl + F` pour rechercher le nom du plat, modifie la valeur puis valide avec **Commit changes**. Netlify republiera le site automatiquement.

Pour une photo : ouvre le dossier `assets`, téléverse la nouvelle image avec **Add file** → **Upload files**, puis modifie le nom du fichier utilisé dans `index.html` si nécessaire. La solution la plus simple est de conserver les noms d'images existants si tu remplaces un visuel.

## Check-list avant de communiquer le lien

- [ ] Le site fonctionne sur mobile.
- [ ] Le bouton d'appel ouvre le bon numéro.
- [ ] Les prix, horaires et adresse sont justes.
- [ ] Les mentions légales sont complétées.
- [ ] Le nom et la catégorie de la fiche Google correspondent à l'activité réelle.
- [ ] La propriété Search Console est validée.
- [ ] Aucune offre payante ni recharge automatique n'a été activée.


## Étape 10 — vérifier les liens vers les réseaux sociaux

Le site comporte maintenant une section « Suivez Best Poulet sur les réseaux » et des raccourcis dans le pied de page :

- **Facebook :** https://www.facebook.com/p/Best-Poulet-61594046682815/
- **TikTok :** https://www.tiktok.com/@bestpouletmeaux
- **Instagram :** lien provisoire proposé sous la forme https://www.instagram.com/bestpouletmeaux/

**Important :** le lien Instagram exact n'était pas dans le message reçu : le premier lien transmis était la documentation de déploiement Netlify. L'adresse Instagram ci-dessus est donc une hypothèse fondée sur le nom TikTok `bestpouletmeaux` et doit être vérifiée en l'ouvrant avant de publier le site. Si ce n'est pas le bon compte, ouvre `index.html` dans GitHub, clique sur le crayon, recherche `instagram.com/bestpouletmeaux`, remplace l'adresse aux deux endroits où elle apparaît, puis clique sur **Commit changes**. Netlify redéploiera le site automatiquement.

Documentation Netlify fournie : https://docs.netlify.com/deploy/create-deploys/ — elle explique les différentes façons de publier et de mettre à jour un site.


## Visuels du logo et des produits (version mise à jour)
Cette version utilise le logo fourni par Best Poulet et des visuels recadrés depuis le flyer officiel : poulet entier, demi-poulet, pilons, ailes, menus, riz, penne, alloco et menu familial. Lors du téléversement sur GitHub, il faut envoyer `index.html`, `robots.txt`, `netlify.toml`, `README.md` et le dossier complet `assets` à la racine du dépôt. Si `assets` est omis ou placé dans un sous-dossier, les images ne s'afficheront pas.
