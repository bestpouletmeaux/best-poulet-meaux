# Plan SEO local — Best Poulet, Meaux

## Cible et promesse

**Requête principale :** rôtisserie halal à Meaux.

**Requêtes secondaires prioritaires :** poulet rôti halal Meaux ; restaurant poulet Meaux ; menu poulet Meaux ; poulet entier rôti Meaux ; menu poulet halal Meaux ; poulet à emporter Meaux.

**Zone réaliste :** Meaux en priorité, puis les communes proches réellement desservies (par exemple Villenoy, Nanteuil-lès-Meaux et Trilport). Ne créez pas des pages quasi identiques pour des dizaines de villes : la priorité est une seule page locale solide, précise et utile.

Aucune stratégie ne peut garantir la première place partout : les résultats locaux dépendent notamment de la pertinence, de la distance et de la notoriété. L'objectif est d'améliorer ces trois dimensions au fil du temps.

## Priorité 1 — fiche Google Business Profile

### Avant toute modification importante

Le restaurant précédent était présenté comme Pinsa Romana et la nouvelle activité est Best Poulet. Google précise qu'un changement de nom qui ne respecte pas ses critères de rebranding est traité comme un nouvel établissement ; dans ce cas, la procédure officielle prévoit de fermer l'ancienne fiche et de créer la nouvelle. Comme la fiche semble déjà apparaître sous le nom Best Poulet dans certains résultats, **ne la supprimez pas et ne créez pas un doublon immédiatement**. Vérifiez si la fiche actuelle correspond bien à l'exploitation Best Poulet, à qui appartiennent les avis et si l'ancien restaurant est réellement fermé. En cas de doute, demandez confirmation à l'assistance Google Business Profile avant de modifier/fermer une fiche.

### Informations à vérifier et corriger

1. **Nom de l'établissement :** `Best Poulet`, exactement comme sur l'enseigne. Ne pas ajouter « rôtisserie halal Meaux 77 » dans le nom si ces mots ne font pas partie de l'enseigne réelle.
2. **Catégorie principale :** dans « Modifier la fiche » > « Catégorie d'activité », saisir `rôtisserie` et sélectionner cette catégorie si Google la propose. Si elle n'apparaît pas, choisir la catégorie proposée la plus spécifique qui décrit réellement l'activité (par exemple une catégorie de restaurant de poulet si disponible, sinon restaurant/restauration rapide). N'ajouter des catégories secondaires que pour de vrais services.
3. **Adresse :** 50 rue du Faubourg Saint-Nicolas, 77100 Meaux. Vérifier que le repère est placé à la bonne entrée.
4. **Téléphone :** 01 78 71 28 37.
5. **Horaires :** les informations récupérées indiquent 11 h 30–23 h, sept jours sur sept. Confirmez les horaires en pratique et renseignez les horaires spéciaux/jours fériés.
6. **Description :** exemple à adapter : « Best Poulet est une rôtisserie halal à Meaux (77), au 50 rue du Faubourg Saint-Nicolas. Nous proposons poulet rôti, poulet entier ou demi-poulet, cuisses, ailes, pilons, escalopes, menus avec accompagnement et boisson, ainsi que riz, pommes de terre, penne, alloco, frites, sauces et desserts. Menus à partir de 7 €. Sur place et à emporter. »
7. **Menu de la fiche :** saisir les plats et prix par rubriques (poulets, menus, accompagnements, sauces, desserts/boissons), plutôt que de dépendre uniquement des photos du flyer.
8. **Photos :** déposer le logo, la façade/entrée, la salle, le comptoir, les poulets et les accompagnements réels. Privilégier des photos nettes faites dans le restaurant, puis ajouter de nouvelles photos régulièrement.
9. **Site et liens :** ajouter l'URL Netlify finale dans « Site Web ». Ajoutez un lien de commande uniquement si vous disposez réellement de ce service.
10. **Questions et avis :** répondre de façon personnalisée, professionnelle et rapide à tous les avis, positifs comme négatifs.

La catégorie principale compte pour la pertinence locale. Google peut demander une nouvelle validation après modification d'une catégorie.

## Priorité 2 — avis clients, sans risque de sanction

- Dans Google Business Profile : « Lire les avis » > « Obtenir plus d'avis » > copier le lien ou télécharger le QR code.
- Placez le QR code à la caisse et sur le ticket/emballage si possible.
- Demandez à tous les clients de partager honnêtement leur expérience ; ne sollicitez pas uniquement les clients satisfaits.
- N'offrez jamais de dessert, réduction ou cadeau en échange d'un avis. N'achetez pas d'avis et ne faites pas écrire des avis aux proches qui n'ont pas réellement consommé.
- Répondez en citant un détail réel, sans répéter artificiellement les mots-clés.

## Priorité 3 — site web

Le site comporte déjà : titre SEO, description, un seul H1 local, texte unique, adresse et téléphone, carte HTML avec prix, visuels, accès à la carte Google Maps après clic et données structurées Restaurant.

Après mise en ligne :

- ajouter l'URL dans la fiche Google ;
- ajouter la propriété Search Console et demander l'indexation ;
- créer le sitemap à partir du modèle une fois l'URL finale connue ;
- vérifier une fois par mois que les prix, horaires, photos et informations de contact sont exacts ;
- mettre en place un suivi simple dans Search Console : impressions, clics, requêtes et pages.

## Priorité 4 — présence locale gratuite

- Harmoniser le même nom, adresse et téléphone sur Instagram, Facebook, PagesJaunes et les autres annuaires que vous utilisez déjà.
- Créer/compléter gratuitement Bing Places for Business et Apple Business Connect.
- Publier sur la fiche Google des actualités utiles : plat du moment, menu familial, accompagnement, horaires exceptionnels, nouveautés. Une publication doit informer, pas seulement contenir des mots-clés.
- Dans Instagram et TikTok, intégrer « Best Poulet — Meaux » dans la bio, les légendes et l'information de localisation ; renvoyer au site dans la bio.
- Utiliser des images originales verticales pour les réseaux et quelques photos paysage pour la fiche Google.

## Calendrier d'exécution

### Jours 1–3

- Vérifier la bonne fiche Google et le statut de l'ancien établissement avant toute fermeture/création.
- Confirmer le nom exact, l'adresse, le téléphone, les horaires, les prix et les mentions légales.
- Corriger la catégorie, la description et le lien du site une fois la fiche correctement identifiée.

### Jours 4–7

- Publier le site, valider Search Console et demander l'indexation.
- Mettre le menu dans la fiche Google, rubrique par rubrique.
- Charger 8 à 12 photos réelles et de bonne qualité (façade, comptoir, produits, salle, équipe avec accord).

### Semaine 2

- Poser le QR code d'avis à la caisse.
- Publier 2 actualités Google, 3 posts Instagram et 2 vidéos TikTok réutilisables.
- Vérifier les liens, horaires et adresse sur chaque canal.

### Semaines 3–4

- Répondre aux avis et questions.
- Tester les requêtes depuis des zones différentes de Meaux, sans supposer qu'un seul résultat représente tout le classement local.
- Regarder Search Console une fois que des données remontent, enrichir le contenu selon les requêtes observées et ajouter des photos de produits qui suscitent des questions.

## Publicité Google à 0 €

Il n'existe pas de campagne Google Ads permanente gratuite pour une petite entreprise. Les crédits promotionnels ponctuels sont soumis à des conditions et demandent généralement des dépenses préalables. Avec un budget nul, concentrez les efforts sur la fiche Google, le référencement du site, les avis authentiques, les posts Google et les contenus sociaux locaux.
