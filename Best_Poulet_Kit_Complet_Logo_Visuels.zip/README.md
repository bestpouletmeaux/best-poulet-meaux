# Best Poulet — site vitrine

Site vitrine statique de Best Poulet, rôtisserie halal à Meaux (77).

## Appels pour commander
Le bouton vert **« Appeler pour passer commande »** est présent dans l'en-tête, dans la section d'accueil et dans une barre fixe sur téléphone. Il utilise le lien `tel:+33178712837` : sur un smartphone, appuyer dessus ouvre l'application Téléphone. Vérifiez le numéro avant publication.

## Identité visuelle et produits
- `assets/logo-best-poulet.webp` : logo fourni directement pour Best Poulet.
- `assets/photo-*.webp`, `assets/produit-*.webp`, `assets/menu-*.webp`, `assets/accompagnement-*.webp` : visuels recadrés depuis le flyer transmis.
- La page d’accueil affiche maintenant la photo du poulet et le logo comme de vraies images HTML (et non uniquement en arrière-plan CSS).

## Fichiers
- `index.html` : page d'accueil, menu et prix, coordonnées, appel à commander, carte/itinéraire et informations de référencement.
- `assets/` : logo et visuels utilisés par le site.
- `robots.txt` : autorise les moteurs de recherche à explorer le site.
- `netlify.toml` : paramètres de publication à la racine du projet.

## Publication conseillée
1. Mettre **tout le contenu de ce dossier, y compris le dossier `assets` et ses images** dans un dépôt GitHub public nommé `best-poulet-meaux-site`.
2. Connecter ce dépôt à Netlify depuis `https://app.netlify.com/start`.
3. Ne pas définir de commande de build ; le dossier de publication est la racine (`.`).
4. Netlify fournit une adresse publique gratuite en `netlify.app` et peut republier automatiquement à chaque modification du dépôt.

## Avant publication
- Vérifier le téléphone, tous les prix, l'adresse et les horaires.
- Remplacer l'encadré « À compléter avant publication » du pied de page par les mentions légales exactes de la société.
- Après avoir obtenu l'adresse publique, compléter les éléments SEO dépendant de cette URL (notamment l'URL canonique et l'image de partage, si souhaité), puis ajouter le site à Google Search Console.

**Important :** GitHub reste le dépôt des fichiers. Pour un site d'entreprise qui permet aux visiteurs d'appeler afin de commander, ne pas utiliser GitHub Pages comme hébergement gratuit : les conditions officielles disent que Pages n'est pas prévu pour les sites principalement orientés vers les transactions commerciales. Utilisez un hébergeur statique compatible tel que Netlify.


## Réseaux sociaux
La page inclut des raccourcis vers Facebook et TikTok, ainsi qu'un lien Instagram provisoire. Vérifiez que `https://www.instagram.com/bestpouletmeaux/` est bien le compte officiel avant publication : l'URL exacte Instagram n'a pas été fournie.
